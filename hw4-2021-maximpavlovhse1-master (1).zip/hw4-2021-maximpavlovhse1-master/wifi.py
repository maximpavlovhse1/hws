# -*- coding: utf-8 -*-
"""
Created on Mon May 10 21:41:41 2021

@author: I
"""

import argparse
import json
from scipy.io import netcdf
import numpy as np
import matplotlib.pyplot as plt




parser = argparse.ArgumentParser()







parser.add_argument('data',  metavar='dat')



if __name__ == "__main__":
    args = parser.parse_args()
    




        
code = np.array([1, 1, 1, -1, -1, -1, 1, -1, -1, 1, -1], dtype = np.int8)

code_r = np.repeat(code, 5) 



file = open(args.data)
data = np.genfromtxt(file, delimiter=' ')




z = np.convolve(data, code_r[::-1], mode = "full")

time = np.arange(z.shape[0])
mean = np.mean(z)
std = np.std(z)
#print(mean, std)
peaks_1 = z > ( mean + 2*std)  
peaks_2 = z < (mean - 2*std)
plt.figure(figsize = (12, 6))
plt.plot(z)
plt.plot(time[peaks_2], z[peaks_2], "*", color = 'orange')
plt.figure(figsize = [12, 6])
plt.plot(np.convolve(code_r, code_r[::-1]))




a = time[peaks_1]
b = time[peaks_2]

for i in range(1, len(time[peaks_1])):
    if (a[i] - a[i-1]) < 1.5:
        a[i-1] = 0
        
        
for i in range(1, len(time[peaks_2])):
    if (b[i] - b[i-1]) < 1.5:
        b[i-1] = 0
        

        

b = b*(-1)





ans1 = []    
for i in range(len(a)):
    if a[i] != 0:
        ans1.append(a[i])
             
       

ans2 = []    
for i in range(len(b)):
    if b[i] != 0:
        ans2.append(b[i])
             

        


peacks =sorted(np.concatenate((ans1, ans2)), key = abs)

c = []
for i in range(len(peacks)):
    if peacks[i] > 0:
        c.append(1)
    elif peacks[i] < 0:
        c.append(0)

print(c)
print(len(c))



c = np.packbits(c)
answer = bytes(c).decode("ascii")
#print(answer)
res = {"message": answer}
with open("wifi.json", "w") as f:
    json.dump(res, f)
