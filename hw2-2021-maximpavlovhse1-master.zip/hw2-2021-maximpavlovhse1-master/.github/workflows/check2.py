#!/usr/bin/env python3

import sys
import os
import os.path
sys.path.append(os.getcwd())
from opt import lm, gauss_newton, Result
