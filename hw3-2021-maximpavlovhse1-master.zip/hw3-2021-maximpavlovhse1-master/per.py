#!/usr/bin/env python3


from mixfit import em_double_cluster


if __name__ == "__main__":
    pass
