from mixfit import max_likelihood, em_double_gauss, em_double_cluster

import unittest

class MixFitTest(unittest.TestCase):
    def test_likelihood(self):
        pass
